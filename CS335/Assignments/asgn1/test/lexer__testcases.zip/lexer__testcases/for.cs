// #include <stdio.h>
// int main(){
//     int i=6;
//     for (;i<= 8 && i>= 6 && i!= 7; i++){
//         if (i>=0){
//             printf("yes\n");
//         }
//         else 
//             printf("no\n");
//     }
//     return 0;
// }

using System;

public class Test
{
	public void Main()
	{
		int i=6;
		for(;i<=8 && i>=6 && i!=7; i++){
			if(i>=0){
				Console.WriteLine("yes\n");
			}
			else
				Console.WriteLine("no\n");
		}
	}
}
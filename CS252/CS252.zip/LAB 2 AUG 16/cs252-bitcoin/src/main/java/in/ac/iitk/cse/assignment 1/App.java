package in.ac.iitk.cse.cs252;

import org.bitcoinj.core.*;
import org.bitcoinj.kits.WalletAppKit;
import org.bitcoinj.params.RegTestParams;
import org.bitcoinj.script.Script;
import org.bitcoinj.wallet.Wallet;
import org.bitcoinj.wallet.listeners.KeyChainEventListener;
import org.bitcoinj.wallet.listeners.ScriptsChangeEventListener;
import org.bitcoinj.wallet.listeners.WalletCoinsReceivedEventListener;
import org.bitcoinj.wallet.listeners.WalletCoinsSentEventListener;

import java.io.File;
import java.util.List;

import org.bitcoinj.core.listeners.TransactionConfidenceEventListener;

public class App {

    public static void main(String[] args) {

				// Update the code here and complete as per the problem statement
        NetworkParameters params = RegTestParams.get();

        WalletAppKit walletA = new WalletAppKit(params, new File("."), "walletA-wallet");
	walletA.connectToLocalHost();

				// Update the code here and complete as per the problem statement
	walletA.startAsync();
	
	System.out.println("send money to: " + walletA.wallet().freshReceiveAddress().toString());

	walletA.awaitRunning();

	walletA.wallet().addCoinsReceivedEventListener(new WalletCoinsReceivedEventListener() {
            @Override
            public void onCoinsReceived(Wallet wallet, Transaction tx, Coin prevBalance, Coin newBalance) {
                System.out.println("-----> coins resceived: " + tx.getHashAsString());
                System.out.println("received: " + tx.getValue(wallet));
            }
	});

	walletA.awaitTerminated();

    }

}

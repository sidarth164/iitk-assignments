package Problem_2;

import Problem_1.ButtonGrid;

public class main {
    public static void main(String[] args){
        TextEditor text = new TextEditor();
    }
}

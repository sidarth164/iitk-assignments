#include <bits/stdc++.h>

using namespace std;


void operate(int* ar, int start, int end);

int main(){
	int C,q,i,j,l,r;
	cin>>C;


	int ar[C];

	for(int a=0;a<C;a++)
		cin>>ar[a];

	cin>>q;
	operate(ar,0,C-1);
	if(q==0) return 0;
	//print permutated array ar;
	cout<<"Permutaed Array: ";
	for(int a=0;a<C;a++)
		cout<<ar[a]<<' ';
	

	cin>>i>>j>>l>>r;

	int asum[C];
	asum[0]= (ar[0]<=r && ar[0]>=l) ? ar[0] : 0;
	// cout<<"\tValue l : r :\t"<<l<<"\t"<<r<<endl;
	for(int a=1;a<C;a++){
		if(ar[a]<=r && ar[a]>=l) 
			asum[a]=asum[a-1]+ar[a];
		else
			asum[a]=asum[a-1];
	}

	// //print sum array ar;
	// cout<<"Sum Array: ";
	// for(int a=0;a<C;a++)
	// 	cout<<asum[a]<<' ';
	// cout<<endl;

	int res=0;
	if(i==0) res=asum[j];
	else res=asum[j]-asum[i-1];
	// cout<<"Value i : j : sum : \t"<<i<<"\t"<<j<<"\t"<<res<<endl;
	cout<<res<<endl;
	for(int a=1;a<q;a++){
		cin>>i>>j>>l>>r;
		if(i==0) res=asum[j];
		else res=asum[j]-asum[i-1];
		// cout<<"Value i : j : sum : \t"<<i<<"\t"<<j<<"\t"<<res<<endl;
		cout<<res<<endl;
	}

}

// operate on section of input array between indices start, end.
void operate(int* ar, int start, int end){
	if(start >= end) return;

	int len  = end-start+1;
	int len0 = ceil(len/3.0);
	int len2 = floor(len/3.0);
	int len1 = len-len0-len2;
	
	int copyArray[len];
	int p  = 0;
	int p2 = start;
	int p1 = start+len2;
	int p0 = start+len2+len1;
	for(int j = 0; j < len; j++){
		copyArray[j] = ar[start+j];
	}

	while(p<len){
		if(p%3 == 0){
			ar[p0] = copyArray[p];
			p0++;
		}
		else if(p%3 == 1){
			ar[p1] = copyArray[p];
			p1++;
		}
		else{
			ar[p2] = copyArray[p];
			p2++;
		}
		p++;
	}

	operate(ar,start,start+len2-1);
	operate(ar,start+len2,start+len2+len1-1);
	operate(ar,start+len2+len1,end);

}

#include<stdio.h>
//#include<math.h>
long long int sum;
long long int l, r, n;
int P = 1000000007;
long long int cceil(long long int a, long long int b)
{
	long long int temp;
	temp = a/b + (a%b >0);
	return temp;
}
long long int ffloor(long long int a, long long int b)
{
	long long int temp;
	temp = a/b ;
	return temp;
}

int FindSum(long long int Start, long long int diff, long long int len )
{
    int sum;
    if(len <= 0)
    return 0;
    
    long long int min, max;
    if(Start > r )
        return 0;
    
    long long int end = Start +(len -1)*diff;
    if(end < l)
        return 0;
    
    if(Start >= l)
        min = Start;
    else
        min = Start + diff*cceil( (l-Start), diff  );
    
    if(end <= r)
        max = end;
    else
        max = Start + diff*ffloor((r-Start),diff );
    
    long long int num = ( max-min )/diff +1 ;
    
    if(num == 0)
    return 0;
    
    if(num%2 != 0 )
    {
        long long int H 	=  ( (max + min)/2 )%P;
        long long int G 	= 	num % P;
        sum  		= 	(H*G)%P;
    }
    else
    {
        long long int H 	=  ( (max + min))%P;
        long long int G 	= 	(num/2) % P;
        sum  		= 	(H*G)%P;
        
    }
   
    return sum % P;
    
}

void Function3( long long int j, long long int I, long long int J,long long int Start,long long int diff)
{

	if( I > J)
	return ;
	if(j < 0 ||J < j ||I <0 || J < 0 || j >= n || I >= n || J >= n)
	return ;


    long long int j3, i3, j2,i2,j1,i1, len3,len2,len1;
    long long int len = (J-I+1);
    len3 = cceil(len,3);
    len1 = ffloor(len,3);
    len2 = len - (len1 + len3);
    j3 = J;
    i3 = j3 - len3 + 1;
    j2 = i3 -1;
    i2 = j2 - len2 + 1;
    j1 = i2 -1;
    i1 = I;
    
    if( J == j )
    {
        sum = (sum + FindSum(Start, diff, len))%P;
        return;
    }
    else if(j <= j1)
    {
        Function3(j, i1, j1, Start + 2*diff , 3*diff );
        return;
    }
    else if(j <= j2)
    {
        sum = ( sum + FindSum(Start + 2*diff, 3*diff, len1) )%P;
        Function3(j, i2, j2, Start + diff, 3*diff );
        return;
    }
    else
    {
        sum = ( sum + FindSum(Start + 2*diff,3*diff, len1) )%P;
        sum = ( sum + FindSum(Start + diff, 3*diff, len2) )%P;
        Function3(j, i3, j3, Start , 3*diff );
        return;
        
    }
    
    return;
}


void Function2(long long int i, long long int I, long long int J, long long int Start, long long int diff)
{


	if( I > J)
	return ;
	if(i <0 ||  I > i ||I <0 || J < 0 || i >=n || I >= n || J >= n)
	return ;

    long long int j3, i3, j2,i2,j1,i1, len3,len2,len1;
    long long int len = (J-I+1);
    len3 = cceil(len,3.0);
    len1 = ffloor(len,3.0);
    len2 = len - (len1 + len3);
    j3 = J;
    i3 = j3 - len3 + 1;
    j2 = i3 -1;
    i2 = j2 - len2 + 1;
    j1 = i2 -1;
    i1 = I;
    
    if( I == i )
    {
        sum = ( sum + FindSum(Start, diff, len) )%P;
        return;
    }
    else if(i >= i3 )
    {
        Function2(i, i3, j3, Start, 3*diff );
        return;
    }
    else if(i >= i2)
    {
        sum = ( sum + FindSum(Start, 3*diff, len3) )%P;
        Function2(i, i2, j2, Start + diff, 3*diff );
        return;
    }
    else
    {
        sum = ( sum + FindSum(Start,3*diff,len3) )%P;
        sum = ( sum + FindSum(Start + diff, 3*diff,len2) )%P;
        Function2(i, i1, j1, Start + 2*diff, 3*diff );
        return;
        
    }
    
    return;
}

void Function1(long long int i, long long int j, long long int I, long long int J, long long int Start, long long int diff )
{

	if(i >j || I > J)
	return ;
	if(i <0 || j < 0 || I > i || J < j ||I <0 || J < 0 || i >=n || j >= n || I >= n || J >= n)
	return ;
	
	long long int j3, i3, j2,i2,j1,i1, len3,len2,len1, new_start;
	long long int len = (J-I+1);
	len3 = cceil(len,3);
	len1 = ffloor(len,3);
	len2 = len - (len1 + len3);
	j3 = J;
	i3 = j3 - len3 + 1;
	j2 = i3 -1;
	i2 = j2 - len2 + 1;
	j1 = i2 -1;
	i1 = I;
	
	if ( (I == i) && (J == j) )
	{
		sum = (sum + FindSum(Start, diff, len) )%P;
		
		return ;
	}
	
	if ( ( i >= i1 && j <= j1 ) || ( i >= i2 && j <= j2 ) || ( i >= i3 && j <= j3 ) )
	{
		if( i >= i1 && j <= j1 )
		{
			new_start = Start + 2*diff;
			Function1(i, j, i1, j1, new_start, 3*diff);
			return ;
		}
		else if( i >= i2 && j <= j2 )
		{
			new_start = Start + diff;
			Function1(i, j, i2, j2, new_start, 3*diff);
			return ;
		}
		else if( i >= i3 && j <= j3 )
		{
			new_start = Start ;
			Function1(i, j, i3, j3, new_start, 3*diff);
			return ;
		}

	}
	else
	{
		if( ( i >= i1 && j <= j2 ) || (i >= i2 && j <= j3 ) )
		{
						
			if( i >= i1 && j <= j2 )
			{
			
				Function2(i, i1, j1, Start+ 2*diff, 3*diff );
				Function3(j, i2, j2, Start+ diff, 3*diff);
				
				return;
				
			}
			if( i >= i2 && j <= j3  )
			{
				Function2(i, i2, j2,Start + diff, 3*diff);
				Function3(j , i3, j3, Start, 3*diff);
				
				return;			
			}
	
		}
		else
		{
            sum = (sum + FindSum(Start + diff, 3*diff,len2))%P;
          
			Function2(i, i1, j1, Start+ 2*diff, 3*diff );
			
			Function3(j , i3, j3, Start, 3*diff);
			
			return;
		}

	}
	

	
}

int main()
{
	long long int q, i ,j;
	scanf("%lld %lld",&n,&q);
	if(n <= 0)
	return 0;
	
	for(int h = 0; h< q ; h++)
	{
		sum  = 0;
		scanf("%lld %lld %lld %lld",&i,&j,&l,&r);
    	Function1(i,j,0, n-1, 0, 1);
        printf("%lld\n", sum);
        
	}
    return 0;
}
